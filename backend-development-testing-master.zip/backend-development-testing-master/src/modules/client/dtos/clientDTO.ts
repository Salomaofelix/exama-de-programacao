export type ClientDTO = {
  id?: string;
  name: string;
};
